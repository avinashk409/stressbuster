#import <Flutter/Flutter.h>

@interface FlutterCashfreePgSdkPlugin : NSObject<FlutterPlugin>
@end
