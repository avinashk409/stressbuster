package com.cashfree.flutter_cashfree_pg_sdk_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
