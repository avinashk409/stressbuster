class CFException implements Exception {
  String message;
  CFException(this.message);
}