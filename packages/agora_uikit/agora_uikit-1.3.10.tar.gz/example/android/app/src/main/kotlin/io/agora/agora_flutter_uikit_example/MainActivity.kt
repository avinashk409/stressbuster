package io.agora.agora_flutter_uikit_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
