package io.agora.agora_uikit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
