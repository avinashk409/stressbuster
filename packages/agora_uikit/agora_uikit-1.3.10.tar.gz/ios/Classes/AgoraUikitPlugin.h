#import <Flutter/Flutter.h>

@interface AgoraUikitPlugin : NSObject<FlutterPlugin>
@end
