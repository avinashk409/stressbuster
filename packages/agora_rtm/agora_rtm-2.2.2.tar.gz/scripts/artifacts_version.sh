set -e

export IRIS_CDN_URL_ANDROID="https://download.agora.io/sdk/release/iris_2.2.1-dev.4_RTM_Android_Video_20240808_0551_578.zip"
export IRIS_CDN_URL_IOS="https://download.agora.io/sdk/release/iris_2.2.1-dev.4_RTM_iOS_Video_20240808_0551_479.zip"
export IRIS_CDN_URL_MACOS="https://download.agora.io/sdk/release/iris_4.3.2-build.1_DCG_Mac_Video_20240604_0500_404.zip"
export IRIS_CDN_URL_WINDOWS="https://download.agora.io/sdk/release/iris_4.3.2-build.1_DCG_Windows_Video_20240604_0456_441.zip"
