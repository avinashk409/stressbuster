A simple command-line application.
