#import <FlutterMacOS/FlutterMacOS.h>

@interface IrisTesterPlugin : NSObject<FlutterPlugin>
@end
