//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <iris_tester/iris_tester_plugin_c_api.h>

void RegisterPlugins(flutter::PluginRegistry* registry) {
  IrisTesterPluginCApiRegisterWithRegistrar(
      registry->GetRegistrarForPlugin("IrisTesterPluginCApi"));
}
