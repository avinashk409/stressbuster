//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import iris_tester

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  IrisTesterPlugin.register(with: registry.registrar(forPlugin: "IrisTesterPlugin"))
}
