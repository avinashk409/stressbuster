import 'package:iris_tester/src/platform/iris_tester_interface.dart';
import 'package:iris_tester/src/platform/web/iris_tester_web.dart';

IrisTester createIrisTester() => IrisTesterWeb();
