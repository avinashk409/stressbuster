import 'package:iris_tester/src/platform/io/iris_tester_io.dart';
import 'package:iris_tester/src/platform/iris_tester_interface.dart';

IrisTester createIrisTester() => IrisTesterIO();
